@echo off
setlocal EnableExtensions
title PC Wireless Mic - Setup
set "PCWM_SELF=%~f0"

:: ---- 1. Make sure we run as Administrator (UAC prompt) --------------------
fltmc >nul 2>&1 && goto :admin
if /i "%~1"=="elevated" goto :noadmin
echo Asking Windows for administrator permission (needed for the audio driver and firewall)...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath $env:PCWM_SELF -ArgumentList 'elevated' -Verb RunAs"
if errorlevel 1 goto :cancelled
exit /b
:cancelled
echo Setup was cancelled.
pause
exit /b
:noadmin
echo Could not get administrator rights. Right-click this file and choose "Run as administrator".
pause
exit /b

:: ---- 2. Extract the PowerShell section of this file and run it ------------
:admin
cls
echo ============================================================
echo   PC Wireless Mic - one-click setup for Windows 11
echo ============================================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$t=[IO.File]::ReadAllText($env:PCWM_SELF);$a=$t.IndexOf('#PS_'+'BEGIN');$b=$t.IndexOf('#APP_'+'BEGIN');$p=Join-Path $env:TEMP 'pcwm_setup.ps1';[IO.File]::WriteAllText($p,$t.Substring($a,$b-$a),(New-Object System.Text.UTF8Encoding($true)));& $p"
echo.
pause
exit /b

#PS_BEGIN
# ===================== POWERSHELL INSTALLER (runs elevated) =====================
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$AppName    = 'PC Wireless Mic'
$AppVersion = '1.0.0'
$Port       = 8443
$FwRule     = 'PC Wireless Mic Server'
$InstallDir = Join-Path $env:LOCALAPPDATA 'PCWirelessMic'
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
try { Start-Transcript -Path (Join-Path $InstallDir 'install.log') -Force | Out-Null } catch {}

function Step([int]$n, [string]$text) { Write-Host ''; Write-Host ("[{0}/6] {1}" -f $n, $text) -ForegroundColor Cyan }
function Info([string]$text)          { Write-Host "      $text" -ForegroundColor DarkGray }

# True only for a real Python 3.9-3.14 that also has Tk (the Microsoft Store "python" stub fails this test).
function Test-Python([string]$exe) {
    if (-not $exe) { return $false }
    try {
        $out = & $exe -c "import sys, tkinter, venv; print(int((3,9) <= sys.version_info[:2] <= (3,14)))" 2>$null
        return ($LASTEXITCODE -eq 0 -and "$out".Trim() -eq '1')
    } catch { return $false }
}

function Find-Python {
    $cands = @()
    $py = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($py) {
        try { $p = & $py.Source -3 -c "import sys; print(sys.executable)" 2>$null; if ($p) { $cands += "$p".Trim() } } catch {}
    }
    foreach ($c in @(Get-Command python.exe -All -ErrorAction SilentlyContinue)) { $cands += $c.Source }
    foreach ($d in 'Python314','Python313','Python312','Python311','Python310') {
        $cands += (Join-Path $env:ProgramFiles "$d\python.exe")
        $cands += (Join-Path $env:LOCALAPPDATA "Programs\Python\$d\python.exe")
    }
    foreach ($c in ($cands | Select-Object -Unique)) {
        if ((Test-Path $c) -and (Test-Python $c)) { return $c }
    }
    return $null
}

function Install-Python {
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($winget) {
        Info 'Installing Python 3.12 with winget (this can take a minute)...'
        & $winget.Source install -e --id Python.Python.3.12 --scope machine --silent --accept-package-agreements --accept-source-agreements | Out-Null
        if ($LASTEXITCODE -eq 0) { return }
        Info 'winget did not finish - using the python.org installer instead.'
    }
    $exe = Join-Path $env:TEMP 'python-3.12.10-amd64.exe'
    Info 'Downloading Python 3.12 from python.org...'
    Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe' -OutFile $exe -UseBasicParsing
    Start-Process -FilePath $exe -ArgumentList '/quiet','InstallAllUsers=1','PrependPath=1','Include_launcher=1','Include_tcltk=1' -Wait
}

function Test-VbCable {
    try {
        if (Get-CimInstance Win32_SoundDevice | Where-Object { $_.Name -match 'VB-Audio|CABLE' }) { return $true }
    } catch {}
    return $false
}

function Install-VbCable {
    $urls = @()
    try {
        $html = (Invoke-WebRequest -Uri 'https://vb-audio.com/Cable/' -UseBasicParsing -TimeoutSec 20).Content
        $m = [regex]::Match($html, 'VBCABLE_Driver_Pack\d+\.zip')
        if ($m.Success) { $urls += "https://download.vb-audio.com/Download_CABLE/$($m.Value)" }
    } catch {}
    $urls += 'https://download.vb-audio.com/Download_CABLE/VBCABLE_Driver_Pack43.zip'
    $zip = Join-Path $env:TEMP 'VBCABLE_Driver_Pack.zip'
    $dir = Join-Path $env:TEMP 'VBCABLE_Setup'
    $ok  = $false
    foreach ($u in ($urls | Select-Object -Unique)) {
        try { Info "Downloading $u"; Invoke-WebRequest -Uri $u -OutFile $zip -UseBasicParsing; $ok = $true; break }
        catch { Info "Download failed: $($_.Exception.Message)" }
    }
    if (-not $ok) { throw 'Could not download VB-CABLE. Check your internet connection and run setup again.' }
    if (Test-Path $dir) { Remove-Item $dir -Recurse -Force }
    Expand-Archive -Path $zip -DestinationPath $dir -Force
    $setup = Get-ChildItem -Path $dir -Recurse -Filter 'VBCABLE_Setup_x64.exe' | Select-Object -First 1
    if (-not $setup) { $setup = Get-ChildItem -Path $dir -Recurse -Filter 'VBCABLE_Setup.exe' | Select-Object -First 1 }
    if (-not $setup) { throw 'The VB-CABLE setup program was not found in the download.' }
    Info 'Installing the driver. If Windows asks "Would you like to install this device software?", choose Install.'
    Start-Process -FilePath $setup.FullName -ArgumentList '-i','-h' -Wait -WorkingDirectory $setup.DirectoryName
    for ($i = 0; $i -lt 15 -and -not (Test-VbCable); $i++) { Start-Sleep -Seconds 2 }
}

function Stop-App {
    Get-CimInstance Win32_Process -Filter "Name LIKE 'python%'" |
        Where-Object { $_.CommandLine -like '*wireless_mic.py*' } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}

function New-AppShortcut([string]$path) {
    $s = (New-Object -ComObject WScript.Shell).CreateShortcut($path)
    $s.TargetPath       = $script:pythonw
    $s.Arguments        = "`"$script:appPy`""
    $s.WorkingDirectory = $InstallDir
    $s.IconLocation     = "$env:SystemRoot\System32\mmsys.cpl,0"
    $s.Description      = 'Use your phone as a PC microphone'
    $s.Save()
}

$failed = $false
try {
    Step 1 'Looking for Python...'
    $python = Find-Python
    if (-not $python) { Install-Python; $python = Find-Python }
    if (-not $python) { throw 'Python 3.9+ (with Tk) could not be found or installed.' }
    Info $python

    Step 2 'Looking for the VB-CABLE virtual audio driver...'
    $cableNew = $false
    if (Test-VbCable) { Info 'Already installed.' } else { Install-VbCable; $cableNew = $true }
    $cableOk = Test-VbCable

    Step 3 "Opening port $Port in Windows Firewall (home/office network only)..."
    Get-NetFirewallRule -DisplayName $FwRule -ErrorAction SilentlyContinue | Remove-NetFirewallRule
    New-NetFirewallRule -DisplayName $FwRule -Direction Inbound -Action Allow -Protocol TCP -LocalPort $Port -RemoteAddress LocalSubnet -Profile Any | Out-Null

    Step 4 'Creating the private Python environment and installing packages...'
    Stop-App
    $venv = Join-Path $InstallDir 'venv'
    $vpy  = Join-Path $venv 'Scripts\python.exe'
    $script:pythonw = Join-Path $venv 'Scripts\pythonw.exe'
    if ((Test-Path $vpy) -and -not (Test-Python $vpy)) { Remove-Item $venv -Recurse -Force }
    if (-not (Test-Path $vpy)) {
        & $python -m venv $venv
        if ($LASTEXITCODE -ne 0) { throw 'Could not create the Python environment.' }
    }
    & $vpy -m pip install --disable-pip-version-check --quiet aiohttp sounddevice numpy cryptography qrcode pillow
    if ($LASTEXITCODE -ne 0) { throw 'pip could not install the required packages (check your internet connection).' }

    Step 5 'Installing the app, shortcuts and uninstaller...'
    $self = [IO.File]::ReadAllText($env:PCWM_SELF)
    $a = $self.IndexOf('#APP_' + 'BEGIN')
    $b = $self.IndexOf('#APP_' + 'END')
    if ($a -lt 0 -or $b -lt $a) { throw 'The app code is missing from this setup file (was it edited or truncated?).' }
    $a = $self.IndexOf("`n", $a) + 1
    $code = $self.Substring($a, $b - $a) -replace "`r`n", "`n"
    $script:appPy = Join-Path $InstallDir 'wireless_mic.py'
    [IO.File]::WriteAllText($script:appPy, $code, (New-Object System.Text.UTF8Encoding($false)))

    $desktopLnk = Join-Path ([Environment]::GetFolderPath('Desktop')) "$AppName.lnk"
    $startLnk   = Join-Path ([Environment]::GetFolderPath('Programs')) "$AppName.lnk"
    New-AppShortcut $desktopLnk
    New-AppShortcut $startLnk

    $uninstallPs1 = Join-Path $InstallDir 'uninstall.ps1'
    $uninstall = @'
$ErrorActionPreference = 'SilentlyContinue'
$id = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $id.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process powershell.exe -Verb RunAs -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File',('"{0}"' -f $PSCommandPath)
    exit
}
$dir = $PSScriptRoot
Write-Host 'Uninstalling PC Wireless Mic...' -ForegroundColor Cyan
Get-CimInstance Win32_Process -Filter "Name LIKE 'python%'" | Where-Object { $_.CommandLine -like '*wireless_mic.py*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
Get-NetFirewallRule -DisplayName 'PC Wireless Mic Server' | Remove-NetFirewallRule
Remove-Item (Join-Path ([Environment]::GetFolderPath('Desktop')) 'PC Wireless Mic.lnk') -Force
Remove-Item (Join-Path ([Environment]::GetFolderPath('Programs')) 'PC Wireless Mic.lnk') -Force
Remove-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\PCWirelessMic' -Recurse -Force
Start-Process cmd.exe -WindowStyle Hidden -ArgumentList '/c', ('timeout /t 2 /nobreak >nul & rmdir /s /q "{0}"' -f $dir)
Write-Host 'Done. The VB-CABLE driver was left installed - remove it from Settings > Apps if you no longer need it.'
Start-Sleep -Seconds 4
'@
    [IO.File]::WriteAllText($uninstallPs1, $uninstall, (New-Object System.Text.UTF8Encoding($true)))

    # Shows up in Settings > Apps > Installed apps
    $reg = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\PCWirelessMic'
    New-Item -Path $reg -Force | Out-Null
    $vals = [ordered]@{
        DisplayName     = $AppName
        DisplayVersion  = $AppVersion
        Publisher       = $AppName
        InstallLocation = $InstallDir
        DisplayIcon     = "$env:SystemRoot\System32\mmsys.cpl,0"
        UninstallString = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$uninstallPs1`""
    }
    foreach ($k in $vals.Keys) { New-ItemProperty -Path $reg -Name $k -Value $vals[$k] -PropertyType String -Force | Out-Null }
    New-ItemProperty -Path $reg -Name NoModify -Value 1 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $reg -Name NoRepair -Value 1 -PropertyType DWord -Force | Out-Null

    Step 6 'Starting PC Wireless Mic...'
    # Launch through Explorer so the app runs as you, not as administrator.
    Start-Process explorer.exe -ArgumentList "`"$desktopLnk`""

    Write-Host ''
    Write-Host 'All done!' -ForegroundColor Green
    Write-Host '  1. Scan the QR code in the app with your phone camera (same Wi-Fi as this PC).'
    Write-Host '  2. On the phone, accept the one-time security warning, then tap the microphone.'
    Write-Host "  3. In Discord / Zoom / OBS / Teams choose 'CABLE Output (VB-Audio Virtual Cable)' as the microphone."
    if ($cableNew -or -not $cableOk) {
        Write-Host ''
        Write-Host 'If the app says VB-CABLE was not found, restart Windows once and open PC Wireless Mic again.' -ForegroundColor Yellow
    }
} catch {
    $failed = $true
    Write-Host ''
    Write-Host "Setup failed: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Details were saved to: $InstallDir\install.log"
}
try { Stop-Transcript | Out-Null } catch {}
if ($failed) { exit 1 }
#APP_BEGIN
"""PC Wireless Mic - use your phone as a microphone on Windows 11.

Phone browser --(wss, 16-bit PCM)--> this app --> VB-CABLE "CABLE Input".
Apps (Discord, Zoom, OBS, Teams...) then use "CABLE Output" as their microphone.
"""
import asyncio
import collections
import ctypes
import datetime
import hmac
import ipaddress
import json
import logging
import logging.handlers
import math
import os
import secrets
import socket
import ssl
import sys
import threading
import time
import tkinter as tk
from tkinter import font as tkfont
from tkinter import messagebox, ttk

import numpy as np

APP_NAME = "PC Wireless Mic"
PORT = 8443
DATA_DIR = os.environ.get("PCWM_DATA") or os.path.join(
    os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "PCWirelessMic")
os.makedirs(DATA_DIR, exist_ok=True)

for _name in ("stdout", "stderr"):  # pythonw.exe has no console streams
    if getattr(sys, _name) is None:
        setattr(sys, _name, open(os.devnull, "w"))
logging.basicConfig(
    handlers=[logging.handlers.RotatingFileHandler(
        os.path.join(DATA_DIR, "app.log"), maxBytes=200000, backupCount=1, encoding="utf-8")],
    level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("pcwm")
sys.excepthook = lambda *a: log.error("Unhandled error", exc_info=a)

CFG_PATH = os.path.join(DATA_DIR, "config.json")


def load_cfg():
    try:
        with open(CFG_PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_cfg(cfg):
    try:
        with open(CFG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f)
    except OSError:
        log.exception("could not save config")


# --------------------------------------------------------------------- network
def local_ips():
    ips = []
    try:  # address of the adapter that owns the default route (no traffic is sent)
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            ips.append(s.getsockname()[0])
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if ip not in ips and not ip.startswith(("127.", "169.254.")):
                ips.append(ip)
    except OSError:
        pass
    return ips or ["127.0.0.1"]


def ensure_certificate(ips):
    """Self-signed certificate (browsers only allow the microphone on https)."""
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID

    cert_path = os.path.join(DATA_DIR, "cert.pem")
    key_path = os.path.join(DATA_DIR, "key.pem")
    wanted = {ipaddress.ip_address(i) for i in ips} | {ipaddress.ip_address("127.0.0.1")}
    now = datetime.datetime.now(datetime.timezone.utc)
    if os.path.exists(cert_path) and os.path.exists(key_path):
        try:
            with open(cert_path, "rb") as f:
                cert = x509.load_pem_x509_certificate(f.read())
            san = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
            expires = getattr(cert, "not_valid_after_utc", None) or \
                cert.not_valid_after.replace(tzinfo=datetime.timezone.utc)
            if wanted <= set(san.get_values_for_type(x509.IPAddress)) and \
                    expires > now + datetime.timedelta(days=30):
                return cert_path, key_path
        except Exception:
            log.exception("existing certificate unusable, creating a new one")

    key = ec.generate_private_key(ec.SECP256R1())
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, APP_NAME)])
    alt = [x509.DNSName("localhost")]
    try:
        alt.append(x509.DNSName(socket.gethostname()))
    except Exception:
        pass
    alt += [x509.IPAddress(ip) for ip in sorted(wanted)]
    cert = (x509.CertificateBuilder()
            .subject_name(name).issuer_name(name).public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now - datetime.timedelta(days=1))
            .not_valid_after(now + datetime.timedelta(days=825))
            .add_extension(x509.SubjectAlternativeName(alt), critical=False)
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
            .sign(key, hashes.SHA256()))
    with open(key_path, "wb") as f:
        f.write(key.private_bytes(serialization.Encoding.PEM,
                                  serialization.PrivateFormat.PKCS8,
                                  serialization.NoEncryption()))
    with open(cert_path, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))
    return cert_path, key_path


def cert_fingerprint(path):
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes
    with open(path, "rb") as f:
        return x509.load_pem_x509_certificate(f.read()).fingerprint(hashes.SHA256()).hex()


# ----------------------------------------------------------------------- audio
class Shared:
    """State shared between the server thread and the window."""
    token = ""
    gain = 1.0
    muted = False
    connected = False
    peer = ""
    phone_rate = 0
    level = 0.0
    fp = ""  # certificate fingerprint, put in the QR code so the phone app can pin it


class Resampler:
    """Streaming linear-interpolation resampler (phone rate -> device rate)."""

    def __init__(self, src, dst):
        self.src, self.dst = int(src), int(dst)
        self.step = self.src / self.dst
        self.pos = 0.0
        self.skip = 0
        self.buf = np.zeros(0, np.float32)

    def process(self, x):
        if self.src == self.dst:
            return x
        if self.skip:
            cut = min(self.skip, len(x))
            x, self.skip = x[cut:], self.skip - cut
        self.buf = np.concatenate((self.buf, x))
        n = len(self.buf)
        if n < 2:
            return np.zeros(0, np.float32)
        count = int((n - 1 - self.pos) // self.step) + 1
        if count <= 0:
            return np.zeros(0, np.float32)
        idx = self.pos + np.arange(count) * self.step
        out = np.interp(idx, np.arange(n), self.buf).astype(np.float32)
        new_pos = self.pos + count * self.step
        drop = int(new_pos)
        if drop >= n:
            self.skip, self.buf = drop - n, self.buf[:0]
        else:
            self.buf = self.buf[drop:]
        self.pos = new_pos - drop
        return out


class JitterBuffer:
    """Small thread-safe FIFO between the network and the sound card."""

    def __init__(self, rate):
        self.lock = threading.Lock()
        self.chunks = collections.deque()
        self.frames = 0
        self.primed = False
        self.prebuffer = int(rate * 0.08)   # start playing after ~80 ms
        self.maxframes = int(rate * 0.40)   # never lag more than ~400 ms
        self.keep = int(rate * 0.15)

    def clear(self):
        with self.lock:
            self.chunks.clear()
            self.frames = 0
            self.primed = False

    def push(self, x):
        if len(x) == 0:
            return
        with self.lock:
            self.chunks.append(x)
            self.frames += len(x)
            if self.frames > self.maxframes:
                while self.frames > self.keep and len(self.chunks) > 1:
                    self.frames -= len(self.chunks.popleft())
            if not self.primed and self.frames >= self.prebuffer:
                self.primed = True

    def pull(self, n):
        out = np.zeros(n, np.float32)
        with self.lock:
            if not self.primed:
                return out
            pos = 0
            while pos < n and self.chunks:
                c = self.chunks[0]
                take = min(len(c), n - pos)
                out[pos:pos + take] = c[:take]
                pos += take
                self.frames -= take
                if take == len(c):
                    self.chunks.popleft()
                else:
                    self.chunks[0] = c[take:]
            if pos < n:
                self.primed = False  # ran dry: refill before playing again
        return out


class AudioOut:
    def __init__(self):
        self.stream = None
        self.rate = 48000
        self.buffer = JitterBuffer(self.rate)

    @staticmethod
    def list_outputs():
        import sounddevice as sd
        apis = sd.query_hostapis()
        wasapi = next((i for i, a in enumerate(apis) if "WASAPI" in a["name"]), None)
        return [(i, d["name"]) for i, d in enumerate(sd.query_devices())
                if d["max_output_channels"] > 0 and (wasapi is None or d["hostapi"] == wasapi)]

    def open(self, index):
        import sounddevice as sd
        self.close()
        info = sd.query_devices(index)
        api = sd.query_hostapis(info["hostapi"])["name"]
        channels = 2 if info["max_output_channels"] >= 2 else 1
        attempts = []
        if "WASAPI" in api:
            attempts.append((48000, sd.WasapiSettings(auto_convert=True)))
        attempts.append((int(info["default_samplerate"]), None))
        last = None
        for rate, extra in attempts:
            try:
                buf = JitterBuffer(rate)

                def callback(outdata, frames, t, status, buf=buf):
                    outdata[:] = buf.pull(frames)[:, None]

                stream = sd.OutputStream(device=index, samplerate=rate, channels=channels,
                                         dtype="float32", callback=callback,
                                         extra_settings=extra, latency="low")
                stream.start()
                self.stream, self.rate, self.buffer = stream, rate, buf
                log.info("output opened: %s @ %d Hz (%s)", info["name"], rate, api)
                return
            except Exception as e:
                last = e
                log.warning("could not open %s at %d Hz: %s", info["name"], rate, e)
        raise last

    def close(self):
        if self.stream is not None:
            try:
                self.stream.stop()
                self.stream.close()
            except Exception:
                pass
            self.stream = None


# ---------------------------------------------------------------------- server
class Session:
    def __init__(self, shared, audio):
        self.shared, self.audio = shared, audio
        self.src_rate = 0
        self.rs = None

    def hello(self, rate):
        if 8000 <= rate <= 192000:
            self.src_rate = rate
            self.shared.phone_rate = rate
            self.rs = None

    def feed(self, data):
        n = len(data) // 2
        if n == 0 or not self.src_rate:
            return
        x = np.frombuffer(data, dtype="<i2", count=n).astype(np.float32) * (1.0 / 32768.0)
        self.shared.level = float(np.sqrt(np.mean(x * x)))
        audio = self.audio
        if self.rs is None or self.rs.dst != audio.rate:
            self.rs = Resampler(self.src_rate, audio.rate)
        y = self.rs.process(x)
        if self.shared.muted:
            y = np.zeros_like(y)
        else:
            y = np.clip(y * self.shared.gain, -1.0, 1.0)
        audio.buffer.push(y)


class Server:
    def __init__(self, shared, audio):
        self.shared, self.audio = shared, audio
        self.loop = None
        self.active = None
        self.error = None
        self.ready = threading.Event()

    def start(self, certfile, keyfile):
        self.certfile, self.keyfile = certfile, keyfile
        threading.Thread(target=self._thread, name="server", daemon=True).start()
        self.ready.wait(15)
        if self.error:
            raise self.error

    def _thread(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        try:
            self.loop.run_until_complete(self._start())
        except BaseException as e:
            self.error = e
            self.ready.set()
            return
        self.ready.set()
        self.loop.run_forever()

    async def _start(self):
        from aiohttp import web
        app = web.Application()
        app.router.add_get("/", self.index)
        app.router.add_get("/ws", self.ws)
        runner = web.AppRunner(app, access_log=None)
        await runner.setup()
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(self.certfile, self.keyfile)
        await web.TCPSite(runner, "0.0.0.0", PORT, ssl_context=ctx).start()
        log.info("server listening on port %d", PORT)

    def _authorized(self, request):
        return hmac.compare_digest(request.query.get("k", "").encode(), self.shared.token.encode())

    async def index(self, request):
        from aiohttp import web
        if not self._authorized(request):
            return web.Response(status=403, content_type="text/plain",
                                text="Open the link from the QR code shown in the PC Wireless Mic app.")
        return web.Response(text=PAGE, content_type="text/html", headers={"Cache-Control": "no-store"})

    async def ws(self, request):
        from aiohttp import WSMsgType, web
        if not self._authorized(request):
            return web.Response(status=403)
        sock = web.WebSocketResponse(heartbeat=10, max_msg_size=1 << 20)
        await sock.prepare(request)
        old, self.active = self.active, sock
        if old is not None and not old.closed:
            # never wait for a dead phone to answer: the new connection must start right away
            asyncio.ensure_future(self._close_quietly(old, 4000, b"replaced"))
        shared = self.shared
        shared.connected, shared.peer, shared.phone_rate, shared.level = True, request.remote or "", 0, 0.0
        self.audio.buffer.clear()
        log.info("phone connected: %s", shared.peer)
        session = Session(shared, self.audio)
        try:
            async for msg in sock:
                if msg.type == WSMsgType.TEXT:
                    try:
                        session.hello(int(json.loads(msg.data).get("rate", 0)))
                    except (ValueError, TypeError, AttributeError):
                        pass
                elif msg.type == WSMsgType.BINARY:
                    session.feed(msg.data)
        finally:
            if self.active is sock:
                self.active = None
                shared.connected, shared.level = False, 0.0
                log.info("phone disconnected")
        return sock

    @staticmethod
    async def _close_quietly(sock, code, message):
        try:
            await sock.close(code=code, message=message)
        except Exception:
            pass

    def kick(self):
        sock = self.active
        if sock is not None and self.loop is not None:
            asyncio.run_coroutine_threadsafe(sock.close(code=4001, message=b"reset"), self.loop)


# --------------------------------------------------------------- phone web page
PAGE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#14161b">
<title>PC Wireless Mic</title>
<style>
:root{--bg:#14161b;--panel:#1d2027;--edge:#2c313b;--ink:#eceff4;--dim:#9aa3b2;--tally:#ff5a36}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{height:100%;margin:0;background:var(--bg);color:var(--ink);font:16px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
main{min-height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:22px;text-align:center;padding:max(24px,env(safe-area-inset-top)) 24px max(24px,env(safe-area-inset-bottom))}
h1{margin:0;font-size:15px;font-weight:600;color:var(--dim)}
#mic{position:relative;width:176px;height:176px;border-radius:50%;border:1px solid var(--edge);background:var(--panel);color:var(--ink);display:grid;place-items:center;cursor:pointer;transition:background .2s,color .2s,border-color .2s}
#mic:focus-visible{outline:3px solid var(--ink);outline-offset:4px}
#mic svg{width:64px;height:64px}
#mic::after{content:"";position:absolute;inset:-10px;border-radius:50%;border:2px solid var(--tally);opacity:0}
body[data-state=live] #mic{background:var(--tally);border-color:var(--tally);color:#1a0a05}
body[data-state=live] #mic::after{animation:ring 1.8s ease-out infinite}
body[data-state=connecting] #mic{opacity:.65}
@keyframes ring{0%{opacity:.7;transform:scale(.96)}100%{opacity:0;transform:scale(1.14)}}
@media (prefers-reduced-motion:reduce){body[data-state=live] #mic::after{animation:none;opacity:.5}}
#label{margin:0;font-size:20px;font-weight:600}
.meter{width:min(280px,70vw);height:6px;border-radius:3px;background:var(--panel);overflow:hidden}
.meter i{display:block;height:100%;background:var(--tally);transform-origin:left;transform:scaleX(0)}
#status{margin:0;min-height:3em;max-width:30ch;color:var(--dim);font-size:14px}
body[data-state=error] #status{color:#ffb4a3}
.opt{display:flex;gap:10px;align-items:center;color:var(--dim);font-size:14px}
.opt input{width:18px;height:18px;accent-color:var(--tally)}
</style>
</head>
<body data-state="idle">
<main>
  <h1>PC Wireless Mic</h1>
  <button id="mic" aria-pressed="false" aria-label="Microphone on or off">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="3" width="6" height="11" rx="3"></rect><path d="M5 11a7 7 0 0 0 14 0M12 18v3"></path></svg>
  </button>
  <p id="label">Tap to start</p>
  <div class="meter"><i id="bar"></i></div>
  <p id="status" role="status"></p>
  <label class="opt"><input type="checkbox" id="clean" checked> Reduce background noise</label>
</main>
<script>
(function () {
  var $ = function (id) { return document.getElementById(id); };
  var key = new URLSearchParams(location.search).get("k") || "";
  var WORKLET = "class P extends AudioWorkletProcessor{constructor(){super();this.b=new Float32Array(2048);this.n=0}process(i){var c=i[0]&&i[0][0];if(c){for(var k=0;k<c.length;k++){this.b[this.n++]=c[k];if(this.n===2048){this.port.postMessage(this.b.slice(0));this.n=0}}}return true}}registerProcessor('pcwm',P)";
  var ctx = null, stream = null, ws = null, node = null, wake = null, live = false;

  function setState(state, text) {
    document.body.dataset.state = state;
    $("label").textContent = state === "live" ? "On air" : state === "connecting" ? "Connecting" : "Tap to start";
    $("mic").setAttribute("aria-pressed", state === "live" ? "true" : "false");
    $("status").textContent = text;
    if (state !== "live") $("bar").style.transform = "scaleX(0)";
  }
  function level(rms) {
    var db = 20 * Math.log10(rms + 1e-6);
    $("bar").style.transform = "scaleX(" + Math.max(0, Math.min(1, (db + 60) / 60)) + ")";
  }
  function send(f) {
    var pcm = new Int16Array(f.length), sum = 0;
    for (var i = 0; i < f.length; i++) {
      var s = Math.max(-1, Math.min(1, f[i]));
      pcm[i] = s < 0 ? s * 32768 : s * 32767;
      sum += s * s;
    }
    level(Math.sqrt(sum / f.length));
    if (ws && ws.readyState === 1 && ws.bufferedAmount < 131072) ws.send(pcm.buffer);
  }
  async function attach(src) {
    var silent = ctx.createGain();
    silent.gain.value = 0;
    silent.connect(ctx.destination);
    if (ctx.audioWorklet) {
      var url = URL.createObjectURL(new Blob([WORKLET], { type: "application/javascript" }));
      await ctx.audioWorklet.addModule(url);
      node = new AudioWorkletNode(ctx, "pcwm");
      node.port.onmessage = function (e) { send(e.data); };
    } else {
      node = ctx.createScriptProcessor(2048, 1, 1);
      node.onaudioprocess = function (e) { send(e.inputBuffer.getChannelData(0)); };
    }
    src.connect(node);
    node.connect(silent);
  }
  function cleanup() {
    live = false;
    var s = ws; ws = null;
    try { if (s && s.readyState < 2) s.close(); } catch (e) {}
    try { if (node) node.disconnect(); } catch (e) {}
    try { if (stream) stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
    try { if (ctx) ctx.close(); } catch (e) {}
    try { if (wake) wake.release(); } catch (e) {}
    node = ctx = stream = wake = null;
  }
  async function keepAwake() {
    try {
      if ("wakeLock" in navigator) {
        wake = await navigator.wakeLock.request("screen");
        wake.addEventListener("release", function () { wake = null; });
      }
    } catch (e) {}
  }
  async function start() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setState("error", "This browser blocks the microphone on this page. Open the link in Chrome (Android) or Safari (iPhone) and accept the certificate warning.");
      return;
    }
    setState("connecting", "Starting the microphone...");
    var clean = $("clean").checked;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, echoCancellation: clean, noiseSuppression: clean, autoGainControl: false } });
    } catch (e) {
      setState("error", "Microphone access was blocked. Allow it for this site, then tap again.");
      return;
    }
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      ctx = new AC({ latencyHint: "interactive" });
      await ctx.resume();
      await attach(ctx.createMediaStreamSource(stream));
    } catch (e) {
      cleanup();
      setState("error", "Could not start audio: " + e.message);
      return;
    }
    var sock = new WebSocket((location.protocol === "https:" ? "wss://" : "ws://") + location.host + "/ws?k=" + encodeURIComponent(key));
    var opened = false;
    ws = sock;
    sock.onopen = function () {
      opened = true;
      sock.send(JSON.stringify({ type: "hello", rate: ctx.sampleRate }));
      live = true;
      setState("live", "Your voice is going to the PC. Keep this page open and the screen on.");
      keepAwake();
    };
    sock.onclose = function (ev) {
      if (sock !== ws) return;
      cleanup();
      var msg = ev.code === 4000 ? "Another phone took over."
        : ev.code === 4001 ? "The link was reset. Scan the new QR code."
        : opened ? "Disconnected from the PC."
        : "Could not reach the PC. Check that both are on the same Wi-Fi, then scan the QR code again.";
      setState(opened ? "idle" : "error", msg);
    };
  }
  $("mic").onclick = function () {
    if (document.body.dataset.state === "connecting") return;
    if (live || ws) { cleanup(); setState("idle", "Stopped."); } else { start(); }
  };
  document.addEventListener("visibilitychange", function () {
    if (live && document.visibilityState === "visible" && !wake) keepAwake();
  });
  setState("idle", "Tap the microphone to start.");
})();
</script>
</body>
</html>
"""


# ---------------------------------------------------------------------- window
class App(tk.Tk):
    def __init__(self, shared, audio, server, cfg, ips):
        super().__init__()
        self.shared, self.audio, self.server, self.cfg, self.ips = shared, audio, server, cfg, ips
        self.k = max(1.0, self.winfo_fpixels("1i") / 96.0)
        self.disp = 0.0
        self.devs = {}
        self.title(APP_NAME)
        self.resizable(False, False)

        style = ttk.Style(self)
        if "vista" in style.theme_names():
            style.theme_use("vista")
        for f in ("TkDefaultFont", "TkTextFont", "TkMenuFont"):
            tkfont.nametofont(f).configure(family="Segoe UI", size=10)

        wrap = int(380 * self.k)
        body = ttk.Frame(self, padding=int(18 * self.k))
        body.pack(fill="both", expand=True)
        ttk.Label(body, text=APP_NAME, font=("Segoe UI Semibold", 16)).pack(anchor="w")
        ttk.Label(body, text="Scan with the PC Wireless Mic phone app (or your camera).",
                  foreground="#555555").pack(anchor="w", pady=(2, 10))

        self.qr_label = ttk.Label(body)
        self.qr_label.pack()
        row = ttk.Frame(body)
        row.pack(fill="x", pady=(8, 0))
        self.url_var = tk.StringVar()
        ttk.Entry(row, textvariable=self.url_var, state="readonly").pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Copy", command=self.copy_link).pack(side="left", padx=(6, 0))
        ttk.Label(body, wraplength=wrap, foreground="#555555",
                  text="The first time, your phone warns about the certificate. That is expected for "
                       "your own PC: choose Advanced, then continue.").pack(anchor="w", pady=(6, 0))

        self.ip_var = tk.StringVar(value=cfg.get("ip") if cfg.get("ip") in ips else ips[0])
        if len(ips) > 1:
            r = ttk.Frame(body)
            r.pack(fill="x", pady=(10, 0))
            ttk.Label(r, text="PC address").pack(side="left")
            cb = ttk.Combobox(r, values=ips, textvariable=self.ip_var, state="readonly", width=18)
            cb.pack(side="right")
            cb.bind("<<ComboboxSelected>>", lambda e: self.refresh_qr())

        ttk.Separator(body).pack(fill="x", pady=int(12 * self.k))
        self.status = tk.Label(body, anchor="w", font=("Segoe UI Semibold", 11))
        self.status.pack(fill="x")
        self.meter = tk.Canvas(body, height=int(8 * self.k), highlightthickness=0, bg="#e1e1e1")
        self.meter.pack(fill="x", pady=(6, 10))
        self.fill = self.meter.create_rectangle(0, 0, 0, int(8 * self.k), fill="#0f7b0f", width=0)

        r = ttk.Frame(body)
        r.pack(fill="x")
        ttk.Label(r, text="Send audio to").pack(side="left")
        self.dev_var = tk.StringVar()
        self.dev_combo = ttk.Combobox(r, textvariable=self.dev_var, state="readonly", width=34)
        self.dev_combo.pack(side="right")
        self.dev_combo.bind("<<ComboboxSelected>>", lambda e: self.open_device(self.dev_var.get()))
        self.warn = tk.Label(body, anchor="w", justify="left", fg="#c42b1c", wraplength=wrap)
        self.warn.pack(fill="x", pady=(4, 0))

        r = ttk.Frame(body)
        r.pack(fill="x", pady=(8, 0))
        ttk.Label(r, text="Volume").pack(side="left")
        self.gain_var = tk.DoubleVar(value=float(cfg.get("gain", 100)))
        self.gain_lbl = ttk.Label(r, width=5, anchor="e")
        self.gain_lbl.pack(side="right")
        ttk.Scale(r, from_=0, to=200, variable=self.gain_var, command=self.on_gain).pack(
            side="right", fill="x", expand=True, padx=8)
        self.mute_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(body, text="Mute", variable=self.mute_var, command=self.on_mute).pack(anchor="w", pady=(4, 0))

        ttk.Label(body, wraplength=wrap, foreground="#555555", text=(
            "In Discord, Zoom, OBS or Teams, set your microphone to \"CABLE Output "
            "(VB-Audio Virtual Cable)\".")).pack(anchor="w", pady=(12, 0))
        r = ttk.Frame(body)
        r.pack(fill="x", pady=(12, 0))
        ttk.Button(r, text="Sound settings", command=self.open_sound).pack(side="left")
        ttk.Button(r, text="New link", command=self.new_link).pack(side="left", padx=6)

        self.on_gain()
        self.refresh_qr()
        self.populate_devices()
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.tick()

    # --- actions
    def refresh_qr(self):
        import qrcode
        from PIL import ImageTk
        self.cfg["ip"] = self.ip_var.get()
        save_cfg(self.cfg)
        url = "https://%s:%d/?k=%s&f=%s" % (self.ip_var.get(), PORT, self.shared.token, self.shared.fp)
        self.url_var.set(url)
        qr = qrcode.QRCode(border=2, box_size=10, error_correction=qrcode.constants.ERROR_CORRECT_L)
        qr.add_data(url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white").convert("RGB")
        size = int(260 * self.k)
        self.qr_img = ImageTk.PhotoImage(img.resize((size, size), 0))
        self.qr_label.configure(image=self.qr_img)

    def copy_link(self):
        self.clipboard_clear()
        self.clipboard_append(self.url_var.get())

    def new_link(self):
        if not messagebox.askyesno(APP_NAME, "Create a new link? Phones using the old link will be disconnected."):
            return
        self.shared.token = secrets.token_urlsafe(9)
        self.cfg["token"] = self.shared.token
        self.server.kick()
        self.refresh_qr()

    def on_gain(self, _=None):
        v = float(self.gain_var.get())
        self.shared.gain = v / 100.0
        self.gain_lbl.configure(text="%d%%" % round(v))
        self.cfg["gain"] = round(v)

    def on_mute(self):
        self.shared.muted = bool(self.mute_var.get())

    def open_sound(self):
        try:
            os.startfile("ms-settings:sound")
        except Exception:
            log.exception("could not open sound settings")

    def populate_devices(self):
        try:
            outs = AudioOut.list_outputs()
        except Exception as e:
            log.exception("audio device query failed")
            self.warn.configure(text="The audio system is not available: %s" % e)
            return
        self.devs = {name: idx for idx, name in outs}
        names = list(self.devs)
        self.dev_combo["values"] = names
        pick = self.cfg.get("device")
        if pick not in self.devs:
            pick = next((n for n in names if "CABLE Input" in n), None)
        if pick:
            self.dev_var.set(pick)
            self.open_device(pick)
        if not any("CABLE Input" in n for n in names):
            self.warn.configure(text="VB-CABLE was not found. Restart Windows once, or run the setup again.")

    def open_device(self, name):
        try:
            self.audio.open(self.devs[name])
            self.cfg["device"] = name
            save_cfg(self.cfg)
            self.warn.configure(text="" if "CABLE Input" in name else
                                "Audio goes to this device, not the virtual microphone. Fine for testing.")
        except Exception as e:
            log.exception("open device failed")
            self.warn.configure(text="Could not open this device: %s" % e)

    def tick(self):
        s = self.shared
        if s.connected:
            self.status.configure(text="Phone connected (%s)" % s.peer, fg="#0f7b0f")
            db = 20 * math.log10(s.level + 1e-6)
        else:
            self.status.configure(text="Waiting for your phone...", fg="#6b6b6b")
            db = -90.0
        self.disp = max(max(0.0, min(1.0, (db + 60.0) / 60.0)), self.disp * 0.8)
        self.meter.coords(self.fill, 0, 0, self.disp * self.meter.winfo_width(), int(8 * self.k))
        self.after(50, self.tick)

    def on_close(self):
        save_cfg(self.cfg)
        self.audio.close()
        self.destroy()


# ------------------------------------------------------------------------ main
_mutex = None


def single_instance():
    global _mutex
    if os.name != "nt":
        return True
    _mutex = ctypes.windll.kernel32.CreateMutexW(None, False, "Local\\PCWirelessMicSingleInstance")
    return ctypes.windll.kernel32.GetLastError() != 183  # ERROR_ALREADY_EXISTS


def set_dpi():
    if os.name != "nt":
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("PCWirelessMic.App")
    except Exception:
        pass


def fatal(msg):
    log.error(msg)
    try:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(APP_NAME, msg)
        root.destroy()
    except Exception:
        pass
    sys.exit(1)


def main():
    if not single_instance():
        fatal("PC Wireless Mic is already running.")
    set_dpi()
    cfg = load_cfg()
    if not cfg.get("token"):
        cfg["token"] = secrets.token_urlsafe(9)
        save_cfg(cfg)
    ips = local_ips()
    certfile, keyfile = ensure_certificate(ips)
    shared = Shared()
    shared.token = cfg["token"]
    shared.fp = cert_fingerprint(certfile)[:32]
    audio = AudioOut()
    server = Server(shared, audio)
    try:
        server.start(certfile, keyfile)
    except OSError as e:
        fatal("Could not start the server on port %d.\n\n%s\n\nIs another program using that port?" % (PORT, e))
    App(shared, audio, server, cfg, ips).mainloop()


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as exc:
        log.exception("fatal error")
        fatal("PC Wireless Mic hit an unexpected error:\n\n%s\n\nDetails: %s" % (exc, os.path.join(DATA_DIR, "app.log")))
#APP_END
